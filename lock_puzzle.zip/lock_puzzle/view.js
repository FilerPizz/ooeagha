function resizeUI() {

var width=document.documentElement.clientWidth;
var llock = document.getElementsByTagName("td");
document.getElementById( "game" ).style.width = (width - 20) + "px";
//alert(width + "" + llock.length); //decamincow

llock[0].style.width = (width * 65 /300) + "px"; 
llock[0].style.height = (width * 65 /300) + "px"; 

llock[1].style.width = (width * 65 /300) + "px"; 
llock[1].style.height = (width * 65 /300) + "px"; 

llock[2].style.width = (width * 65 /300) + "px"; 
llock[2].style.height = (width * 65 /300) + "px"; 

llock[3].style.width = (width * 65 /300) + "px"; 
llock[3].style.height = (width * 65 /300) + "px"; 

llock[4].style.width = (width * 65 /300) + "px"; 
llock[4].style.height = (width * 65 /300) + "px"; 

llock[5].style.width = (width * 65 /300) + "px"; 
llock[5].style.height = (width * 65 /300) + "px"; 

llock[6].style.width = (width * 65 /300) + "px"; 
llock[6].style.height = (width * 65 /300) + "px"; 

llock[7].style.width = (width * 65 /300) + "px"; 
llock[7].style.height = (width * 65 /300) + "px"; 

llock[8].style.width = (width * 65 /300) + "px"; 
llock[8].style.height = (width * 65 /300) + "px"; 

llock[9].style.width = (width * 65 /300) + "px"; 
llock[9].style.height = (width * 65 /300) + "px"; 

llock[10].style.width = (width * 65 /300) + "px"; 
llock[10].style.height = (width * 65 /300) + "px"; 

llock[11].style.width = (width * 65 /300) + "px"; 
llock[11].style.height = (width * 65 /300) + "px"; 

llock[12].style.width = (width * 65 /300) + "px"; 
llock[12].style.height = (width * 65 /300) + "px"; 

llock[13].style.width = (width * 65 /300) + "px"; 
llock[13].style.height = (width * 65 /300) + "px"; 

llock[14].style.width = (width * 65 /300) + "px"; 
llock[14].style.height = (width * 65 /300) + "px"; 

llock[15].style.width = (width * 65 /300) + "px"; 
llock[15].style.height = (width * 65 /300) + "px"; 


document.getElementById( "cell_1_1" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_1_1" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_1_2" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_1_2" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_1_3" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_1_3" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_1_4" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_1_4" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_2_1" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_2_1" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_2_2" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_2_2" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_2_3" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_2_3" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_2_4" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_2_4" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_3_1" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_3_1" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_3_2" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_3_2" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_3_3" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_3_3" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_3_4" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_3_4" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_4_1" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_4_1" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_4_2" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_4_2" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_4_3" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_4_3" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

document.getElementById( "cell_4_4" ).style.width = (width * 65 /300) + "px"; 
document.getElementById( "cell_4_4" ).style.height = ((width * 65 * 20 / 300)/65) + "px"; 

} 